
function Pipe() {
  // set up variables
  this.x = width-50;
  this.origin = random(height-100);
  this.gap = 100;

  this.show = function() {
    fill(220);
    // sample rectangle
    // top bar rect(x, y, w, h);
    rect(width-50, 0, 55, 155);
    rect(width-50, 300, 55, 200);
  }

  this.update = function(){
    // move across screen
    this.x --;
  }
}
